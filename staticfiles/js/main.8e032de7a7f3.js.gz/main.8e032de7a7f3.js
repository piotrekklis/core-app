function editObject(core_object_id){

    window.location.href = window.location.protocol + "//" + window.location.hostname + ":8000" + window.location.pathname + "edit_core_object/" + core_object_id + "/"

}